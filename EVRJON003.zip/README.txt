Functional programming assignment 1

From the assignment brief I adhered to the naming requirement for the file and function names. Functions that share a name with library functions are called in the file with a Main. prefix. 

Rather than import the code of previous questions into question B5 and B6 I rather copied the previous functions into them. For convenience sake the questions code are copied in the order of the questions so the actual function that I needed to write is always at the end of the file and so is any extra code I wrote for that function.

I was unaware of whether or not we were supposed to use a git repo for this project. So I did to be safe, the repo is on github but the code is private I can share it on request. 

My github username is KarmaZA.

all questions worked on my machine I hope they work on yours too.
